<!--
 * @Author: wyk
 * @Date: 2024-09-23 09:21:38
 * @LastEditTime: 2024-11-25 10:26:02
 * @Description:
-->

# 更新日志

## 2024-11-25

1. **update:** 更新`Await`组件、支持只定义loading、插槽,同时更新`Await`示例

## 2024-11-18

1. **feature:** 新增`Await`组件

## 2024-10-12

1. **fix:** 优化`SelectAll`逻辑,解决异步首次回显状态错误

## 2024-09-20

1. **update:** 优化`SelectAll`逻辑,支持部分全选并根据所选内容调整页面状态
2. **update:** 调整组件库结构,分离组件和开发示例
3. **fix:** 解决组件库自动导入问题
4. **optimize:** 优化`examples`出口文件、根据目录结构自动导出

## 2024-08-30

1. **feature:** 新增`ScrollBar`组件
2. **feature:** 新增`visibleComponent`组件
3. **feature:** 新增`Action`组件

## 2024-06-04

1. **update:** 完善导入配置、支持完整引入、按需导入、手动导入,并提供导入示例
2. **feature:** 新增`按需导入`解析器

## 2024-05-23

1. **feature:** 组件库初始化
2. **feature:** 新增`3D饼图组件`
3. **feature:** 新增`大屏适配组件`
4. **feature:** 新增`SelectAll组件`
5. **feature:** 新增`数字翻牌器`
