<!--
 * @Author: wyk
 * @Date: 2024-05-14 15:30:17
 * @LastEditTime: 2024-05-27 16:51:04
 * @Description:
-->

# button

::: tip

<!-- 使用该组件需要提前安装threeJs、当前所用版本0.164.1 -->

基础按钮组件
:::

## button

<Wy-Button type="primary">111</Wy-Button>

**代码示例**

```vue
<template>
    <Wy-Button />
</template>
```
