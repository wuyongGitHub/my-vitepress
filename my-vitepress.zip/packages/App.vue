<!--
 * @Author: wyk
 * @Date: 2024-05-14 16:51:09
 * @LastEditTime: 2024-05-21 16:31:11
 * @Description:
-->
<template>
    <RouterView></RouterView>
</template>

<script lang="ts" setup>
// import { install,Button } from "ant-design-vue";
defineOptions({
    name: "App",
});
</script>

<style lang="scss" scoped></style>
