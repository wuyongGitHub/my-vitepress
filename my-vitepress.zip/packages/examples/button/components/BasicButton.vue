<!--
 * @Author: wyk
 * @Date: 2024-05-16 14:44:35
 * @LastEditTime: 2024-08-30 11:10:37
 * @Description:
-->
<template>
    <div>
        <Button type="primary">1111</Button>
        <Button type="text">1111</Button>
        <Button type="primary">1111</Button>
        <Button type="primary">1111</Button>
    </div>
</template>

<script setup lang="ts">
defineOptions({ name: "WyButton" });
</script>

<style lang="scss" scoped></style>
