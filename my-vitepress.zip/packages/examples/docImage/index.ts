/*
 * @Author: wyk
 * @Date: 2024-05-23 14:39:20
 * @LastEditTime: 2024-05-23 14:40:39
 * @Description:
 */
import BasicsDocsImage from "./components/BasicsDocImage.vue";
import { withInstall } from "../../utils/tool";
const BqBasicsDocsImage = withInstall(BasicsDocsImage);
export { BqBasicsDocsImage };
