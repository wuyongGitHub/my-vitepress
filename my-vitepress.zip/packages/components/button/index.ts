/*
 * @Author: wyk
 * @Date: 2024-05-14 15:43:54
 * @LastEditTime: 2024-05-21 16:13:00
 * @Description:
 */
import Button from "./Button.vue";
import { withInstall } from "../../utils/tool";
// import "@/styles/element/index.scss";
export const WyButton = withInstall(Button);
export default WyButton;
