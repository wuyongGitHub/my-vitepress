import {
  ResizeObserver_es_default
} from "./chunk-YIP7QGVX.js";
import "./chunk-G3PMV62Z.js";
export {
  ResizeObserver_es_default as default
};
//# sourceMappingURL=resize-observer-polyfill.js.map
